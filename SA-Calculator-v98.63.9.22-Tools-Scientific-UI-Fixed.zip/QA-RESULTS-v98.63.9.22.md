# QA results — v98.63.9.22

## Focused release gate
- Node tests: **44/44 passed, 0 failed**.
- JavaScript source syntax: PASS.
- Generated Android web bundle syntax: PASS.
- Service worker syntax: PASS.
- Android web bundle: PASS — 13 required assets verified.
- GitHub Actions YAML parse: PASS.
- App/package/manifest/workflow/cache release identity: PASS (`1.98.70-v98.63.9.22`, versionCode `1098070`).
- Source ZIP integrity: PASS.

## New regression coverage
- Three-column tool grid and horizontal labels.
- No per-character label wrapping.
- Four tool groups and 16 unique destinations.
- Vertical scrolling and safe-area bottom padding.
- Scientific drawer width and 4×4 function touch targets.
- Scientific function insertion path retained.
- Fresh service-worker cache and synchronized Android workflow identity.

## Legacy suite
- 361/434 passed; 73 historical assertions failed, mostly old hard-coded release identities and legacy UI expectations.
- These failures are not counted as release-gate passes.

## Not certified
- Native Android APK build/install, emulator or device screenshot parity, touch latency, frame pacing, and OEM gesture compatibility were not run.
