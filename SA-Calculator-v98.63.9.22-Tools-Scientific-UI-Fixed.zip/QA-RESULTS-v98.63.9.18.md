# QA results — v98.63.9.18

- Scientific drawer structure regression: PASS
- Tools scientific-card removal regression: PASS
- Edge-swipe open / reverse-swipe close source regression: PASS
- Close button / Escape / ARIA / inert state regression: PASS
- Scientific function and memory controls preserved: PASS
- JavaScript syntax: PASS
- Android web bundle generation: PASS
- Workflow YAML parse: PASS
- ZIP integrity: PASS

The legacy repository-wide test corpus contains historical assertions that explicitly require the old separate Scientific Calculator screen and exact v98.63.9.17 release identity. Those assertions conflict with this requested v98.63.9.18 change and are not represented as passing. Focused v98.63.9.18 regressions and relevant calculator/scientific engine tests are reported separately.

Physical Android APK installation, swipe gesture latency, device-specific WebView animation, and on-device visual comparison: NOT YET VERIFIED.
