import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const read = rel => fs.readFileSync(path.join(root, rel), 'utf8');
const html = read('index.html');
const js = read('assets/js/app.js');
const css = read('assets/css/app.css');
test('v98.50 has a dedicated Settings destination in the primary navigation', () => {
  const nav = html.match(/<nav class="bottom-navigation"[\s\S]*?<\/nav>/)?.[0] || '';
  for (const id of ['calc', 'history', 'favorites', 'tools', 'settings']) assert.match(nav, new RegExp(`data-bottom-nav="${id}"`));
  assert.equal((nav.match(/data-bottom-nav=/g) || []).length, 5);
});
test('v98.50 hides primary navigation on individual tool screens', () => {
  assert.match(js, /primaryScreens\s*=\s*new Set\(\['calc', 'history', 'favorites', 'tools', 'settings'\]\)/);
  assert.match(js, /nav\.hidden\s*=\s*!primaryScreens\.has\(screenId\)/);
  assert.match(js, /nav\.inert\s*=\s*nav\.hidden/);
});
test('v98.50 no longer globally suppresses Home header; v98.55 hides it only on child screens', () => {
  assert.doesNotMatch(css, /(?:^|\})\s*#app-container > \.app-header\s*\{[^}]*display:\s*none\s*!important/);
  const finalHome = read('assets/css/app.css');
  assert.match(finalHome, /#app-container > \.app-header\s*\{[\s\S]*?display:\s*flex\s*!important/);
  assert.match(finalHome, /body\.tool-screen-active #app-container > \.app-header\{display:none!important\}/);
});
test('v98.50 keeps basic and converter keypad touch targets at 48px minimum', () => {
  assert.match(css, /\.main-keypad \.key-btn\s*\{[\s\S]*?min-height:\s*48px/);
  assert.match(css, /\.currency-dock-keypad button,[\s\S]*?min-height:\s*48px/);
});
test('v98.50 scientific display keeps expression and result independently sized', () => {
  assert.match(css, /\.scientific-expression\s*\{[\s\S]*?min-height:\s*32px/);
  assert.match(css, /\.scientific-result\s*\{[\s\S]*?min-height:\s*30px/);
});
